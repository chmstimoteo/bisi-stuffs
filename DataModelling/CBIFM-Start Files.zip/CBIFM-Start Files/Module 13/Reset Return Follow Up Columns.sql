/* This SQL returns the Returns Followup columns in the RETURNED_ITEM table back to the default settings.
*/
UPDATE gosales.RETURNED_ITEM SET ASSIGNED_TO = NULL, FOLLOW_UP_CODE = -1, COMMENTS = NULL, DATE_ADVISED = NULL