peril <- read.csv(file = 'original.txt', header = TRUE, sep = ";")

peril[1:10,]

summary(peril)

pairs(~p1+p2+p3+p4+p5+p6+imp ,data=peril, main="Scatterplot Matrix")
pairs(~p7+p8+p9+p10+p11+p12+imp, data=peril, main="Scatterplot Matrix")

plot(peril$imp, main="Gamma Normalized Impact Scatterplot", ylab = "Impact")

par(mfrow=c(2,3))
hist(peril$p1, ylab="OCCURRENCES", xlab="VALUES", main="INPUT 1")
hist(peril$p2, ylab="OCCURRENCES", xlab="VALUES", main="INPUT 2")
hist(peril$p3, ylab="OCCURRENCES", xlab="VALUES", main="INPUT 3")
hist(peril$p4, ylab="OCCURRENCES", xlab="VALUES", main="INPUT 4")
hist(peril$p5, ylab="OCCURRENCES", xlab="VALUES", main="INPUT 5")
hist(peril$p6, ylab="OCCURRENCES", xlab="VALUES", main="INPUT 6")
par(mfrow=c(1,1))
par(mfrow=c(2,3))
hist(peril$p7, ylab="OCCURRENCES", xlab="VALUES", main="INPUT 7")
hist(peril$p8, ylab="OCCURRENCES", xlab="VALUES", main="INPUT 8")
hist(peril$p9, ylab="OCCURRENCES", xlab="VALUES", main="INPUT 9")
hist(peril$p10, ylab="OCCURRENCES", xlab="VALUES", main="INPUT 10")
hist(peril$p11, ylab="OCCURRENCES", xlab="VALUES", main="INPUT 11")
hist(peril$p12, ylab="OCCURRENCES", xlab="VALUES", main="INPUT 12")

par(mfrow=c(1,1))
hist(peril$imp, ylab="OCCURRENCES", xlab="Normalized Impact", main="Histogram of Impact")
densityPeril <- density(peril$imp,na.rm=T)
lines(x=densityPeril$x, y=densityPeril$y*40)

mat1 <- cbind(p1 = peril$p1, p2 = peril$p2, p3 = peril$p3, p4 = peril$p4, p5 = peril$p5, p6 = peril$p6, impact = peril$imp)
mat2 <- cbind(p7 = peril$p7, p8 = peril$p8, p9 = peril$p9, p10 = peril$p10, p11 = peril$p11, p12 = peril$p12, impact = peril$imp)
boxplot(as.data.frame(mat1), main = "Input x Output Boxplots")
par(las = 1) # all axis labels horizontal
boxplot(as.data.frame(mat2), main = "Input x Output Boxplots")
par(las = 1) # all axis labels horizontal

#ceiling(nrow(peril)*0.2)
#sample(1:ceiling(nrow(peril)*0.2))

set.seed(sample(1:100, 1, replace=TRUE))
sample <- peril[sample(1:nrow(peril)),]
sample10 <- peril[sample(1:ceiling(nrow(peril)*0.1)),]
sample20 <- peril[sample(1:ceiling(nrow(peril)*0.2)),]
regressionModel <- lm(imp~., data=sample)
regressionModel10 <- lm(imp~., data=sample10)
regressionModel20 <- lm(imp~., data=sample20)

#summary(regressionModel)

#summary(regressionModel10)

#summary(regressionModel20)

finalRegressionModel <- step(regressionModel)
#summary(finalRegressionModel)

finalRegressionModel10 <- step(regressionModel10)
summary(finalRegressionModel10)

finalRegressionModel20 <- step(regressionModel20)

library(rpart)
regressionTree <- rpart(imp~., data=sample)
regressionTree10 <- rpart(imp~., data=sample10)
regressionTree20 <- rpart(imp~., data=sample20)

summary(finalRegressionModel20)

summary(finalRegressionModel10)

summary(finalRegressionModel)

plot(sample10$imp, main="10% Randomly Partitioned Sample Scatterplot", ylab = "Gamma Normalized Impact values")

plot(sample20$imp, main="20% Randomly Partitioned Sample Scatterplot", ylab = "Gamma Normalized Impact values")

regressionTree
printcp(regressionTree)
regressionTree10
printcp(regressionTree10)
regressionTree20
printcp(regressionTree20)

boxplot(as.data.frame(finalRegressionModel$residuals), main = "MLRM 100% Residuals Boxplots")

boxplot(as.data.frame(finalRegressionModel10$residuals), main = "MLRM 10% Residuals Boxplots")

boxplot(as.data.frame(finalRegressionModel20$residuals), main = "MLRM 20% Residuals Boxplots")

plot(finalRegressionModel10$residuals, main="Model Residuals Scatterplot", ylab = "Errors value")

plot(finalRegressionModel20$residuals, main="Model Residuals Scatterplot", ylab = "Errors value")

plotcp(regressionTree)
plot(regressionTree)
text(regressionTree, use.n = TRUE, cex = 0.6)

plotcp(regressionTree10)
plot(regressionTree10)
text(regressionTree10, use.n = TRUE, cex = 0.6)

plotcp(regressionTree20)
plot(regressionTree20)
text(regressionTree20, use.n = TRUE, cex = 0.6)

lmprediction <- predict(finalRegressionModel, sample)
rtprediction <- predict(regressionTree, sample)
emalm <- (mean(abs(lmprediction - sample[, "imp"])))
emart <- (mean(abs(rtprediction - sample[, "imp"])))
emalm
emart
lmprediction10 <- predict(finalRegressionModel10, sample)
rtprediction10 <- predict(regressionTree10, sample)
emalm10 <- (mean(abs(lmprediction10 - sample[, "imp"])))
emart10 <- (mean(abs(rtprediction10 - sample[, "imp"])))
emalm10
emart10
lmprediction20 <- predict(finalRegressionModel20, sample)
rtprediction20 <- predict(regressionTree20, sample)
emalm20 <- (mean(abs(lmprediction20 - sample[, "imp"])))
emart20 <- (mean(abs(rtprediction20 - sample[, "imp"])))
emalm20
emart20

peril2 <- peril[sample(nrow(peril)),]
peril_test <- peril2[sample(1:ceiling(nrow(peril)*0.3)),]
#peril_test <- peril2[1:134,]

lmprediction <- predict(finalRegressionModel, peril_test)
rtprediction <- predict(regressionTree, peril_test)
emalm <- (mean(abs(lmprediction - peril_test[, "imp"])))
emart <- (mean(abs(rtprediction - peril_test[, "imp"])))
emalm
emart
write(emalm, file='res_emalm.txt', append = TRUE)
write(emart, file='res_emart.txt', append = TRUE)
lmprediction10 <- predict(finalRegressionModel10, peril_test)
rtprediction10 <- predict(regressionTree10, peril_test)
emalm10 <- (mean(abs(lmprediction10 - peril_test[, "imp"])))
emart10 <- (mean(abs(rtprediction10 - peril_test[, "imp"])))
emalm10
emart10
write(emalm10, file='res_emalm10.txt', append = TRUE)
write(emart10, file='res_emart10.txt', append = TRUE)
lmprediction20 <- predict(finalRegressionModel20, peril_test)
rtprediction20 <- predict(regressionTree20, peril_test)
emalm20 <- (mean(abs(lmprediction20 - peril_test[, "imp"])))
emart20 <- (mean(abs(rtprediction20 - peril_test[, "imp"])))
emalm20
emart20
write(emalm20, file='res_emalm20.txt', append = TRUE)
write(emart20, file='res_emart20.txt', append = TRUE)

lmprediction[1:10]
lmprediction10[1:10]
lmprediction20[1:10]

sample[1:10,"imp"]
rtprediction[1:10]
rtprediction10[1:10]
rtprediction20[1:10]

layout(matrix(c(1,2,3,4),2,2))
plot(finalRegressionModel)

layout(matrix(c(1,2,3,4),2,2))
plot(finalRegressionModel10)

layout(matrix(c(1,2,3,4),2,2))
plot(finalRegressionModel20)

par(mfrow=c(2,4))
termplot(finalRegressionModel)

par(mfrow=c(2,2))
termplot(finalRegressionModel10)

par(mfrow=c(2,2))
termplot(finalRegressionModel20)

plot(rtprediction, peril[, "imp"], main="Regression Tree Model", xlab="Predictions", ylab="True VALUES")
abline(0, 1, lty = 2)

result <- read.csv (file = 'result.csv', header = TRUE, sep = ",")

res1 <- cbind(LM100 = result$emalm, LM10 = result$emalm10, LM20 = result$emalm20)
boxplot(as.data.frame(res1), main = "MAE Boxplots for MLR Models")


res2 <- cbind(RT100 = result$emart, RT10 = result$emart10, RT20 = result$emart20)
boxplot(as.data.frame(res2), main = "MAE Boxplots for RT Models")

res3 <- cbind(LM100 = result$emalm, LM10 = result$emalm10, LM20 = result$emalm20, RT100 = result$emart, RT10 = result$emart10, RT20 = result$emart20)
boxplot(as.data.frame(res3), main = "MAE Boxplots for MLR and RT Models")

wilcox.test(result$emalm, result$emalm10, alternative = "greater", paired = FALSE, conf.level = 0.95)
wilcox.test(result$emalm, result$emalm20, alternative = "greater", paired = FALSE, conf.level = 0.95)
wilcox.test(result$emalm10, result$emalm20, alternative = "greater", paired = FALSE, conf.level = 0.95)

wilcox.test(result$emart, result$emart10, alternative = "greater", paired = FALSE, conf.level = 0.95)
wilcox.test(result$emart, result$emart20, alternative = "greater", paired = FALSE, conf.level = 0.95)
wilcox.test(result$emart10, result$emart20, alternative = "greater", paired = FALSE, conf.level = 0.95)

wilcox.test(result$emalm, result$emart, alternative = "greater", paired = FALSE, conf.level = 0.95)
wilcox.test(result$emalm10, result$emart10, alternative = "greater", paired = FALSE, conf.level = 0.95)
wilcox.test(result$emalm20, result$emart20, alternative = "greater", paired = FALSE, conf.level = 0.95)


