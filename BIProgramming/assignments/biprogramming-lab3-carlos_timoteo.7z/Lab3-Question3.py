# Author: Carlos Timoteo
# Course: BI Programming
# Professor: Steve Conrad
# Lab 3 - Question III Interpret Requirements
# Date: 2017-11-24

# Function to print unacceptable rating
def punacceptable():
    print ("Sorry, your product rating is Unacceptable. Hope you have a better experience next time.")

# Function to print acceptable rating
def pacceptable():
    print ("Great, your product rating is Acceptable! Enjoy it!")

# Function to print the quality rating exceeds
def exceeds():
    print ("Your quality rating Exceeds Quality Standards.")

# Function to print the quality rating fully meets quality standards
def meets():
    print ("Your quality rating Fully Meets Quality Standards.")

# Function to print the quality rating is within tolerance
def within():
    print ("Your quality rating is Within Tolerance of Quality Standards.")

# Function to print the reprocess for quality rating
def reprocess():
    print ("We shall reprocess the product.")

# Function to print review for quality rating
def review():
    print ("The product shall me sent to Quality Review.")

# Function to print discard for quality rating
def discard():
    print ("Please, discard the product.")

# using dictionaries to avoid usage of if,elif,else
#product rating dictionary
pratings = {1:pacceptable, 2:pacceptable, 3:pacceptable, 4:punacceptable, 5:punacceptable, 6:punacceptable}
# quality ratings dictionary
qratings = {1:exceeds, 2:meets, 3:within, 4:reprocess, 5:review, 6:discard}

#main loop, stops when play is False
play = True
while play:
    print ("Hello my name is Sarah! I'll process your evaluations today.")
    print ("The valid inputs are between 1-6, okay?")
    # validating input
    valid= False
    while not valid:
        x = int(input("Enter your Product Rating:"))
        if not 1<=x<=6:
            print ("Ops, invalid input! Please, type a number between 1 and 6:")
        else:
            valid=True
    #call function based on dictionary
    pratings[x]()
    
    #validating input
    valid= False
    while not valid:
        y = int(input("Enter your Quality Rating:"))
        if not 1<=x<=6:
            print ("Ops, invalid input! Please, type a number between 1 and 6:")
        else:
            valid=True
    #call function based on dictionary
    qratings[x]()
    
    #stop criteria. Anything different from "no" will make the evaluations continue.
    if input("Play again? (yes/no)") == "no":
        play = False