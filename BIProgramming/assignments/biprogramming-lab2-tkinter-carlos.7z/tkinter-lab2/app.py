#############################################
# Course: CST2101
# Author: Carlos Timoteo
# Date: 2017-10-09
# Description: Write and modify a simple 
#              Tkinter widget in python.
#############################################

from tkinter import *

class Window(Frame):

    def __init__(self, master=None):
        Frame.__init__(self, master)
        self.master = master
        self.init_window()
    
    def init_window(self):
        #Change the title of the window
        self.master.title("Lab2 - Carlos")
        #Positioning the widget to take full space
        self.pack(fill=BOTH, expand=1)
        
        #Creating the Text field
        message = "Please select your language"
        greetings = Label(self, text=message)
        greetings.place(x=25, y=25)
        greetings.pack()
        self.message = message
        self.greetings = greetings

        #Creating the button instances
        englishButton = Button(self, text="English", command=self.greetings_english)
        #Placing the button
        englishButton.place(x=50, y=50)
        
        spanishButton = Button(self, text="Spanish", command=self.greetings_spanish)
        #Placing the button
        spanishButton.place(x=100, y=100)
        
        frenchButton = Button(self, text="French", command=self.greetings_french)
        #Placing the button
        frenchButton.place(x=150, y=150)
    
    #Callback function for english button
    def greetings_english(self):
        self.greetings.config(text="Hello, Carlos!")

    #Callback function for spanish button
    def greetings_spanish(self):
        self.greetings.config(text="Hola, Carlos!")

    #Callback function for french button    
    def greetings_french(self):
        self.greetings.config(text="Bonjour, Carlos!")
        

def main():
    root = Tk()
    root.geometry("250x200")
    app = Window(root)
    root.mainloop()

if __name__ == "__main__":
    main()