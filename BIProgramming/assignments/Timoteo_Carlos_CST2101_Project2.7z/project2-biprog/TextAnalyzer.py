#!/usr/bin/python3
# Author: Carlos Timoteo
# Course: BI Programming
# Professor: Steve Conrad
# Project 2 - Text Analyzer
# Date: 2017-12-02
from collections import Counter
import re

#Class to instantiate objects responsible by the Text Analysis process
class TextAnalyzer():
    
    def __init__(self, fileContent=""):
        #Initialize all class attributes
        self.occurrenceVector=Counter()
        self.words=0
        self.blankSpaces=0
        self.totalCharacters=0
        self.fileContent=fileContent

    # count #words, #blank spaces and #characters
    def basicStatistics(self):
         # Clean the content a little
        self.fileContent = re.sub('\s+', ' ', self.fileContent)  # condense all whitespace
        self.fileContent = re.sub('[^A-Za-z ]+', '', self.fileContent)  # remove non-alpha chars
        
        words = self.fileContent.split()
        #Set the number of words
        self.words = len(words)
        #Set the number of blank spaces
        self.blankSpaces = self.words-1
        #Set the occurrence vector
        self.occurrenceVector = Counter(self.fileContent.split())

        #set the number of characters
        for words in list(self.occurrenceVector.elements()):
            self.totalCharacters += len(words)
        tempStr=""
        for word, count in self.occurrenceVector.most_common(): 
            tempStr += str("{0},{1}".format(word, count)) + "\n"

        #Set percentage of blank spaces
        percentBlank=self.percentageBlankSpaces()

        #Return the required info in formatted string
        return "Total Non-blank Character Count: %i\nTotal Blank Character Count: %i\nPercentage Blank Character: %s\nTotal Word Count: %i\n" % (self.totalCharacters-self.blankSpaces, self.blankSpaces, percentBlank, self.words)
    
    # Method to print the occurrence vector for each word
    def evaluateOccurenceVector(self):
        tempStr=""
        for item in self.occurrenceVector.items(): 
            tempStr += str("{},{}".format(*item)) + "\n"
        return "Words Occurrences:\n%s" % (tempStr)
    
    # percentage #blank spaces by #characters
    def percentageBlankSpaces(self):
        percentage = (self.blankSpaces / self.totalCharacters) * 100
        return percentage

#Test the Object
def main():
    pass


#Avoid calling main method if this file is imported in another python file
if __name__ == "__main__":
    main()