#!/usr/bin/python3
# Author: Carlos Timoteo
# Course: BI Programming
# Professor: Steve Conrad
# Project 2 - Text Analyzer
# Date: 2017-12-02

import tkinter.messagebox
import tkinter as tk
import tkinter.ttk as ttk
import tkinter.filedialog
from TextAnalyzer import TextAnalyzer

#Fonts used
myfonts = {'times': 'times 18 bold', 'verdana': 'Verdana 10'}
#Files that can be opened
mypatterns = [('Text File', '*.txt'), ('Python', '*.py'), ('Python', '*.pyw')]
#My global variable to set the filename currently load
myfileName = ""

#Main GUI Class that initialize the frame
class GUIPlus(tk.Frame):
    def __init__(self, parent=None):
        #Frame object initializing Frame
        tk.Frame.__init__(self, parent, class_='GUIPlus')
        self.master = parent
        self.master.title('Text Analysis')
        self.master.geometry('500x500+250+50')
        self.master.configure(bg='orange')

        #Setting the keyboards shortcuts and respective callback functions
        self.master.bind('<Control-q>', self.GUIPlusQuit)
        self.master.bind('<Control-o>', self.myfileOpen)
        self.master.bind('<Control-s>', self.myfileSave)
        self.master.bind('<Control-a>', self.analyzeText)

        #Calling method to configure the MenuBar
        self.myBarMenu()

        #Calling method to configure the Notebook and Texts Tabs
        self.myNoteBook()

    #Callback to open a file and load its content to the Input Text widget
    def myfileOpen(self, event=None):
        global myfileName
        try:
            #Open a filedialog to open a file
            self.myfile = tk.filedialog.askopenfile(filetypes=mypatterns,
                                title='Open a Text file', mode='r')
            loadedfile = self.myfile.read()
            myfileName = self.myfile.name
            self.myfile.close()
            self.textView1.delete('1.0', tk.END)
            self.textView1.insert("end", loadedfile)
        #If any exception occur trying to open the file, set it to ""
        except:
            self.myfile = None
            myfileName = ""
            pass
    
    #Callback to create a new file
    def myfileCreate(self):
        global myfileName
        try:
            #Open a filedialog to save a file
            self.myfile = tk.filedialog.asksaveasfile(filetypes=mypatterns,
                                    title='""Save a file', mode='w')
            myfileName = self.myfile.name
            self.myfile.close()
        #If any exception occur trying to open the file, set it to ""
        except:
            self.myfile = None
            myfileName = ""
            pass
    
    #Callback to save a file with the content in Input
    def myfileSave(self, event=None):
        global myfileName
        try:
            #Open a filedialog to save a file
            self.myfile = tk.filedialog.asksaveasfile(filetypes=mypatterns,
                                    title='Save a file', mode='w')
            loadedfile = self.myfile.write(self.textView1.get("1.0",tk.END))
            myfileName = self.myfile.name
            self.myfile.close()
        #If any exception occur trying to open the file, set it to ""
        except:
            self.myfile = None
            myfileName = ""
            pass

    #Method to disassociate the input file and clean the Texts widgets contents
    def myfileClose(self):
        global myfileName
        self.textView1.delete('1.0', tk.END)
        self.textView2.delete('1.0', tk.END)
        myfileName = ""

     #Method to analyse text in the input file and generate the output file
    def analyzeText(self, event=None):
        global myfileName 
        #Check if the file content was loaded to Text area
        content = self.textView1.get(1.0, tk.END)
        if content == "\n" or content == "":
            tk.messagebox.showerror('Empty Text', 'There is no content in the selected input file.', parent=self.master)
            return

        #Check if the filename exists, if not creates it.
        if myfileName == "":
            tk.messagebox.showerror('Input Error', 'No input file selected.', parent=self.master)
            return

        #Instatiate the textAnalyzer object and call analysis methods
        try:
            analyzer = TextAnalyzer(fileContent=content)

            #Prepares the output and calls analyzer methods
            output = []
            tempList = myfileName.split(sep="/")
            output.append("Name of text: " + tempList[len(tempList)-1])
            output.append(analyzer.basicStatistics())
            output.append(analyzer.evaluateOccurenceVector())
            
            #Write the Output file
            outputName = myfileName.split(sep=".")[0] + "_analysis.txt"
            with open(outputName,mode='w') as fw:
                intermediatestring=""
                #Iterate over the intermediate string list
                for i in output:
                    intermediatestring+=str(i) + "\n"
                fw.write(intermediatestring)
                fw.close()

            #Show output file content in the Anaysis tab
            with open(outputName,mode='r') as f:
                lines = f.read()
                self.textView2.delete('1.0', tk.END)
                self.textView2.insert("end", lines)
                f.close()
            
            #Message user when process is done
            tk.messagebox.showinfo('Analysis completed!', 'The Text Analysis was performed. See the Output tab for further information.', parent=self.master)
        except:
            tk.messagebox.showerror('Analysis Error!', 'The Text Analysis was not performed or the output file could not be created. See the Output tab for further information.', parent=self.master)

    #Method to configure the Notebook and the Texts tabs
    def myNoteBook(self):
        self.notebook = ttk.Notebook(self.master, width=500, height=600)
        self.framenotebook1 = ttk.Frame(self.notebook)
        self.framenotebook2 = ttk.Frame(self.notebook)
        self.framenotebook3 = ttk.Frame(self.notebook)
        self.notebook.add(self.framenotebook1, text='Input')
        self.notebook.add(self.framenotebook2, text='Output')
        self.notebook.pack(side='top', expand='yes', fill='both')
        
        #For Tab1
        self.scrollbarView1 = tk.Scrollbar(self.framenotebook1,
                                          orient='vertical', takefocus=False,
                                          highlightthickness=0)
        self.textView1 = tk.Text(self.framenotebook1, bg='black', fg='white',
                         wrap='word', highlightthickness=0)
        self.scrollbarView1.config(command=self.textView1.yview)
        self.textView1.config(yscrollcommand=self.scrollbarView1.set)
        self.scrollbarView1.pack(side='right', fill='y')
        self.textView1.pack(side='left', expand='yes', fill='both')

        #For Tab2
        self.scrollbarView2 = tk.Scrollbar(self.framenotebook2,
                                          orient='vertical', takefocus=False,
                                          highlightthickness=0)
        self.textView2 = tk.Text(self.framenotebook2, bg='white', fg='black',
                         wrap='word', highlightthickness=0)
        self.scrollbarView2.config(command=self.textView2.yview)
        self.textView2.config(yscrollcommand=self.scrollbarView2.set)
        self.scrollbarView2.pack(side='right', fill='y')
        self.textView2.pack(side='left', expand='yes', fill='both')

    #Method to configure the menu bar
    def myBarMenu(self):
        mymenubar = tk.Menu(self.master)

        filemenu = tk.Menu(mymenubar, tearoff=0)
        filemenu.add_command(label='New File', underline=0,
                             accelerator='CTRL+N', command=self.myfileCreate)
        filemenu.add_command(label='Open File', underline=0,
                            accelerator='CTRL+O', command=self.myfileOpen)
        filemenu.add_separator()
        filemenu.add_command(label='Save File', underline=0,
                             accelerator='CTRL+S', command=self.myfileSave)
        filemenu.add_command(label='Save As...', 
                             accelerator='CTRL+SHIFT+S', command=self.myfileSave)
        filemenu.add_command(label='Close File', underline=0,
                             accelerator='ALT+F4', command=self.myfileClose)
        filemenu.add_separator()
        filemenu.add_command(label='Exit', underline=0,
                             accelerator='CTRL+Q', command=self.GUIPlusQuit)
        mymenubar.add_cascade(label='File', underline=0, menu=filemenu)

        analysismenu = tk.Menu(mymenubar, tearoff=0)
        analysismenu.add_command(label='Analyze text', underline=0,
                             accelerator='CTRL+A', command=self.analyzeText)
        mymenubar.add_cascade(label='Analysis', underline=0, menu=analysismenu)

        self.master.configure(menu=mymenubar)

    #Callback to close the application
    def GUIPlusQuit(self, event=None):
        if tk.messagebox.askokcancel('Quit', 'Do you really want to exit?', parent=self.master):
            self.master.destroy()


window = tk.Tk()
myapp = GUIPlus(window)
window.mainloop()