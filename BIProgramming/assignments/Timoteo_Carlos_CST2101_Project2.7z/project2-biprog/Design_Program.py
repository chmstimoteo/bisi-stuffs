# Author: Carlos Timoteo
# Course: BI Programming
# Professor: Steve Conrad
# Project 2 - Text Analyzer
# Date: 2017-12-02

#Must covey the general logic of the program including classes/methods.
#May be constructed as “comments” in a .py file (no programming)
#Must be named Design_Program.<extension>

#Class responsible for Read and Write the Files and present the contents in a TKinter GUI
class GUIPlus(tk.Frame):
    #Constructor method, instantiate the basic objects and calls the configure's methods
    def __init__(self, parent=None):

    #Callback to open a file and load its content to the Input Text widget
    def myfileOpen(self, event=None):
        
    #Callback to create a new file
    def myfileCreate(self):
    
    #Callback to save a file with the content in Input
    def myfileSave(self, event=None):

    #Method to disassociate the input file and clean the Texts widgets contents
    def myfileClose(self):

    #Method to analyse text in the input file and generate the output file
    def analyzeText(self, event=None):

    #Method to configure the Notebook and the Texts tabs
    def myNoteBook(self):

    #Method to configure the menu bar
    def myBarMenu(self):
       
    #Callback to close the application
    def GUIPlusQuit(self, event=None):

#Class to instantiate objects responsible by the Text Analysis process
class TextAnalyzer():
    
    #Constructor method to initialize the basic class attributtes
    def __init__(self, fileContent=""):
     
    #Method to clean the input text string and count #words, #blank spaces and #characters
    def basicStatistics(self):
     
    #Method to print the occurrence vector for each word
    def evaluateOccurenceVector(self):
      
    #Method to calculate the percentage #blank spaces by #characters
    def percentageBlankSpaces(self):