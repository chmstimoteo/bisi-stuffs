#!/usr/bin/python3
# Author: Carlos Timoteo
# Prof: Steve Conrad
# Course: BI Programming CST2101
# Assignment Lab5 - WithoutMe WithMe
# Date: 2017-12-14
from tkinter import *
from tkinter.ttk import *
import tkinter.messagebox
import tkinter as tk


class app():
    
    def __init__(self, master=None):
        #Initialize all the components of the screen
        self.master = master
        
        #Place the images
        self.labelimg1=Label(master)
        self.logo=PhotoImage(file='python.gif')
        Label.img=self.logo
		#Place image corner up-left
        self.labelimg1.grid(row=0, column=0, sticky='W', rowspan=2)
        self.labelimg1.config(image=Label.img)

		#Place image corner up-right
        self.labelimg2=Label(master)
        self.labelimg2.grid(row=0, column=5, sticky='E', rowspan=2)
        self.labelimg2.config(image=Label.img)
		
		#Place image corner down-left
        self.labelimg3=Label(master)
        self.labelimg3.grid(row=5, column=0, sticky='W', rowspan=2)
        self.labelimg3.config(image=Label.img)

		#Place image corner down-right
        self.labelimg4=Label(master)
        self.labelimg4.grid(row=5, column=5, sticky='E', rowspan=2)
        self.labelimg4.config(image=Label.img)

        # Label widget using column pad
        self.label1 = Label(master, text="Entry Your First Name")
        self.label1.grid(row = 2, column = 1, padx=20, pady=20)
        # Entry widget using column pad
        self.sFirstName = StringVar()
        self.eFirstName = Entry(master, width=12, textvariable=self.sFirstName)
        self.eFirstName.grid(row = 2, column = 2, padx=20, pady=20)
        # Label widget using column pad
        self.label2 = Label(master, text="Entry Your Last Name")
        self.label2.grid(row = 3, column = 1, padx=20, pady=20)                                             
        # Entry widget using column pad
        self.sLastName = StringVar()
        self.eLastName = Entry(master, width=12, textvariable=self.sLastName)
        self.eLastName.grid(row = 3, column = 2, padx=20, pady=20)   
        # Button widgets using sticky 
        # Callback addToFile to create WithMe and load the Notebook
        self.myButton = Button(master, text="Add me", command = self.addToFile)
        self.myButton.grid(row =4, column = 1, columnspan=3, padx=20, pady=20, sticky='NSEW')
    
    # Method responsible for setting the RESULT layout and show the content of WithMe file inside a Notebook
    def myNotebook(self):
		#Reset the images in all corner for one doubled the size
        self.logo1=PhotoImage(file='python64.gif')
        Label.img=self.logo1
        self.labelimg1.config(image=Label.img)
        self.labelimg2.config(image=Label.img)
        self.labelimg3.config(image=Label.img)
        self.labelimg4.config(image=Label.img)
		
		#Remove the labels and entries for the first and last name
        self.label1.grid_forget()
        self.label2.grid_forget()
        self.eFirstName.grid_forget()
        self.eLastName.grid_forget()
		
		#Change the command and text of myButton.
        self.myButton.config(text="Exit", command=self.quit)
		#Instanciate a Notebook widget inside a Frame 
        self.notebook = Notebook(self.master, width=200, height=200)
        self.framenotebook1 = Frame(self.notebook)
        self.notebook.add(self.framenotebook1, text='WithMe')
        self.notebook.grid(row =2, column = 1, columnspan=2, rowspan=2, padx=20, pady=20)
		#Usinng Scrollbar to the Frame
        self.scrollbarView = Scrollbar(self.framenotebook1, orient='vertical', takefocus=False)
        self.textView = Text(self.framenotebook1, bg='black', fg='white', wrap='word', highlightthickness=0)
        self.scrollbarView.config(command=self.textView.yview)
        self.textView.config(yscrollcommand=self.scrollbarView.set)
        self.scrollbarView.pack(side='right', fill='y')
        self.textView.pack(side='left', expand='yes', fill='both')

    #Read the WithoutMe.txt file and sort... at last saves WithMe file                     
    def addToFile(self):
		#Check if the last name and first are empty fields. If yes, shows a message error.
        if self.sLastName.get() == "" or self.sFirstName.get() == "":
            tk.messagebox.showerror('Input Error', 'There is one empty field. Fill all fields!', parent=self.master)
        else:
			#Read and sort WithoutMe file
            lines=[]
            with open('WithoutMe.txt',mode='r') as f:
                lines = f.read().splitlines()
                lines.append(self.sLastName.get() + ", " + self.sFirstName.get())
                lines.sort()
				# Removes all empty lines
                while lines[0] == "":
                    lines.pop(0)
                f.close()
			#Open and write WithMe file
            with open('WithMe.txt',mode='w') as fw:
                intermediatestring=""
                #Iterate over the intermediate string list
                for i in lines:
                    intermediatestring+=str(i) + "\n"
                fw.write(intermediatestring)
                fw.close()
            # Loads the RESULT GUI
            self.myNotebook()
			# Write WithMe file content inside Notebook
            self.openFile()

    #Load the file content into the Notebook.
    def openFile(self):
        with open('WithMe.txt',mode='r') as f:
            lines = f.read()
            print(lines)
			#Cleans the textView
            self.textView.delete('1.0', END)
			#Loads the file content
            self.textView.insert("end", lines)
            f.close()
    
    #Close the GUI
    def quit(self, event=None):
        self.master.destroy()

# Create the application
#=============================
def main():
    root = Tk()
    myApp = app(root)
    root.mainloop()

# Start the application
#=============================
#Avoid calling main method if this file is imported in another one
if __name__ == "__main__":
    main()