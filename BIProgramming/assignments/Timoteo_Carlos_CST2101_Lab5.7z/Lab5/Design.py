#!/usr/bin/python3
# Author: Carlos Timoteo
# Nested Logic

# This is a simple GUI application to manage files, reading, writing and inserting new records.


# On start up the GUI displays the Initial GUI
# The user must enter the first name and last name
# If the user does not enter a first name or last name, the program show a warning messagebox asking the user
# to input all empty fields
# When the user clicks on “Add Me” then
#   Open the text file “WithoutMe.txt”
#	Put the file contents in a List
#	Add “Your Name” to the list
#	Sort the list by Last Name, First Name
#	Change the display to the “RESULT” layout and display the list
#	Write the new list to a new file “WithMe.txt
#	When the user clicks on “Exit” then
#       Close the program

