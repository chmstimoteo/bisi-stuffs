#!/usr/bin/python3
# Author: Carlos Timoteo
# Course: BI Programming
# Professor: Steve Conrad
# Lab 4 - 3X+1
# Date: 2017-11-24

#Read the number typed by the user
number=int(input("Type a number: "))
print("User enters ",number)

#Set variables to count the iterations and to store the
#intermediate numbers
iterations=0
intermediate_list=[]
#Loop to iterate over the numbers
while number>0:
  iterations+=1
  if(iterations!=0):
    intermediate_list.append(number)
  #Stop condition, when number is equals 1
  if(number==1):
    break
  #If odd, do 3X+1
  elif(number%2):
    number=(number*3)+1
  #else it's even, divide by 2 
  else:
    number/=2
#When number is 1, print the number of iterations and intermediate values
if(number==1):
  print("Number of iterations: ", iterations)
  intermediatestring=""
  #Iterate over the intermediate numbers list
  for k,i in enumerate(intermediate_list):
    intermediatestring+=str(i) + ", "
  print("Intemediate values: ", intermediatestring[:-2])